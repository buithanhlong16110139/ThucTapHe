export const timeInterval = {
  VERY_LOW: "4h",
  LOW: "1h",
  MEDIUM: "30m",
  HIGH: "15m",
  VERY_HIGH: "5m"
};

export const Types = {
  VERY_LOW: "VERY_LOW",
  LOW: "LOW",
  MEDIUM: "MEDIUM",
  HIGH: "HIGH",
  VERY_HIGH: "VERY_LOW"
};
