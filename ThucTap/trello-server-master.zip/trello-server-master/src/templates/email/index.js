import NoticeSellToken from "./noticeSellToken";
import NoticeSellToken2 from "./noticeSellToken2";

const Templates = {
  NoticeSellTokenTemplate: NoticeSellToken,
  NoticeSellTokenTemplate2: NoticeSellToken2
};

export { Templates as default, NoticeSellToken as NoticeSellTokenTemplate };
