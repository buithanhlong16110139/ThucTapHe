const router = require('express').Router();
// import EmailController from '../../controllers/email';
// let Controller = new EmailController();

// //Middlerwares
// import verify2FA from "../../middlewares/check2fa";
// import authentication from '../../middlewares/authentication';
// import authenticationAdmin from "../../middlewares/authenticationAdmin";

// //Routers method GET
// // router.get('/erroremail', authenticationAdmin, Controller.getErrorEmail);

// //Routers method POST
// router.post('/sendAll', authenticationAdmin, Controller.sendToAllUsers);
// router.post('/sendto', authenticationAdmin, Controller.sendTo);
// router.post('/template/create', authenticationAdmin, Controller.createTemplate);

// //Routers method PUT
// router.post('/template/edit', authenticationAdmin, Controller.createTemplate);

//Routers method DELETE

export default router;
