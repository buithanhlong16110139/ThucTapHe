module.exports = {
  PORT: process.env.PORT || 6969,
  SEND_INTERVAL: 5 // In seconds
}
