module.exports = {
  issuer: 'phamlegiabao1210@gmail.com',
  audience: 'fb.com/giabao.dev',
  algorithm: 'RS256'
}
