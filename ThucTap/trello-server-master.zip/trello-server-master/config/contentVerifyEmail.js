 const getContent = (url) => {
  return `<p>Welcome to CSE Token</p>
  <p>Click the link below to complete verification:</p>
  `+url+`
  <p>If this activity is not your own operation, please contact us immediately.</p>
  <p>support@csetoken.io</p>
  <p>CSE Team</p>
  <p>Automated message. Please do not reply</p>`;
};

export default getContent;