  module.exports = {
  host: "ds155352.mlab.com",
  port: 55352,
  database: "trello",
  username: "admin",
  password: "admin123"
}; 



// module.exports = {
//   host: "localhost",
//   port: 27017,
//   database: "trello-localhost",
// };

